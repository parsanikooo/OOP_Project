import java.time.Duration;
import java.time.LocalTime;
import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Matcher;

public class TwoPlayerMode {
    Controller controller;
    Scanner scanner;
    User Player_1 ;
    User Player_2 ;


    public TwoPlayerMode(Controller controller, Scanner scanner) {
        this.controller = controller ;
        this.scanner = scanner ;
    }


    public void run(){
        Player_1 = User.getUserByUsername(controller.loginMenu.LogedUsername) ;
        LoginPlayer2();




    }

    private void LoginPlayer2(){

        long n = 0 ;
        boolean loginfaild = false ;
        String input = "";
        String input_1 = "";
        Matcher matcher;
        LocalTime startTime = LocalTime.now();
        Duration duration ;
        System.out.println("Please log in Player 2");

        while (true) {
            // if log in failed he must wait 5 * n second
            while (loginfaild) {
                input_1 = scanner.nextLine();
                LocalTime endTime = LocalTime.now();
                duration = Duration.between(startTime, endTime);
                if ((n * 5) > duration.getSeconds()) {
                    System.out.println("Try again in " + (5 * n - duration.getSeconds()) + " seconds");
                } else {
                    break;
                }
            }
            if (loginfaild) {
                input = input_1;
            } else {
                input = scanner.nextLine();
            }
            if ((matcher = controller.getMatcher(input, "user login -u (?<username>.+) -p (?<password>.+)")) != null) {
                String username = matcher.group();
                String password = matcher.group();
                User user;
                if ((user = User.getUserByUsername(username)) == null) {
                    System.out.println("Username doesn’t exist!");
                    loginfaild = true;
                    startTime = LocalTime.now();
                    n++;
                    continue;
                } else if (!Objects.equals(user.getPassword(), password)) {
                    System.out.println("Password and Username don’t match!");
                    loginfaild = true;
                    startTime = LocalTime.now();
                    n++;
                    continue;
                } else {
                    System.out.println("user logged in successfully!");
                     Player_2 = User.getUserByUsername(username) ;
                    loginfaild = false;
                    break;
                }
            }
            else {
                    System.out.println("invalid command !");
            }
        }
    }



}
