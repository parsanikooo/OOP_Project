import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Controller {

    private final Scanner scanner = new Scanner(System.in);
    final SignupMenu singupMenu ;
    final LoginMenu loginMenu ;
    final ProfileMenu profileMenu;
    final GameMenu gameMenu ;
    final TwoPlayerMode twoPlayerMode ;


    public Controller() {
        this.singupMenu = new SignupMenu(this, scanner);
        this.loginMenu = new  LoginMenu (this, scanner) ;
        this.profileMenu = new ProfileMenu(this, scanner) ;
        this.gameMenu = new GameMenu(this, scanner) ;
        this.twoPlayerMode = new TwoPlayerMode(this, scanner) ;
    }


    public Matcher getMatcher(String input, String regex) {
        Matcher matcher = Pattern.compile(regex).matcher(input);
        return matcher.matches() ? matcher : null;
    }



}
