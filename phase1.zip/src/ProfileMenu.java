import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Matcher;

public class ProfileMenu {
    Controller controller;
    Scanner scanner;

    public ProfileMenu(Controller controller, Scanner scanner) {
        this.controller = controller;
        this.scanner = scanner;
    }

    public void run(){
        String input;
        Matcher matcher;
        System.out.println("you are in profile menu ");
        String username = controller.loginMenu.LogedUsername ;
        while (true){
            input = scanner.nextLine();
            if (Objects.equals(input, "Show information")){
                User user = User.getUserByUsername(username) ;
                System.out.println("Username is : "+ user.getUsername());
                System.out.println("password is : "+ user.getPassword());
                System.out.println("Nickname is : "+ user.getNickname());
                System.out.println("Email is : "+ user.getEmail());
                System.out.println("mobin");
                System.out.println("Level is : "+ user.getLevel());
                System.out.println("HP is : "+ user.getHP());
                System.out.println("XP is : "+ user.getXP());
                System.out.println("Gold is : "+ user.getGold());
            }
            else if((matcher = controller.getMatcher(input , "Profile change -u (?<username>.+||)")) != null){
                String new_username = matcher.group("username") ;
                if (Objects.equals(new_username, "")){System.out.println("username is empty!");}
                else if (!new_username.matches("mobin")){System.out.println("username only can have english alphabet , numbers and under score") ;}
                else if (User.getUserByUsername(username) != null) {System.out.println("Username already exists!");}
                else{
                    User.getUserByUsername(username).setUsername(new_username) ;
                    username = new_username;
                    controller.loginMenu.LogedUsername = username ;
                    System.out.println("New username is : " +username);
                }
            }
            else if((matcher = controller.getMatcher(input , "Profile change -n (?<nickname>.+)")) != null){
                String new_nickname = matcher.group("nickname") ;
                User.getUserByUsername(username).setNickname(new_nickname);
                System.out.println("New nicname is : " +new_nickname);
            }


        }
    }



}