import java.util.ArrayList;

public class User {
    private static ArrayList<User> users = new ArrayList<>();
    private String Username ;
    private String Password ;
    private String Nickname ;
    private String Email ;
    private String Question_password_recovery_question  ;
    private String Password_recovery_question ;
    private int Level ;
    private int HP ;
    private int XP ;
    private int Gold ;

    public User(String username , String password , String email ,String nickname ) {
        Username = username;
        Password = password ;
        Email = email ;
        Nickname = nickname ;
        Level = 1 ;
        HP = 100 ;
        XP = 0 ;
        Gold = 100 ;
    }


    public static User getUserByUsername(String username) {
        for (User user : users) {
            if (user.Username.equals(username)) return user;
        }
        return null;
    }
    public static ArrayList<User> getUsers() {
        return users;
    }

    public String getUsername() {
        return Username;
    }
    public String getPassword() {
        return Password;
    }
    public String getNickname() {
        return Nickname;
    }
    public String getEmail() {
        return Email;
    }

    public String getQuestion_password_recovery_question() {
        return Question_password_recovery_question;
    }

    public String getPassword_recovery_question() {
        return Password_recovery_question;
    }

    public int getLevel() {
        return Level;
    }

    public int getHP() {
        return HP;
    }

    public int getXP() {
        return XP;
    }

    public int getGold() {
        return Gold;
    }

    public void setUsername(String username) {
        Username = username;
    }
    public void setPassword(String password) {
        Password = password;
    }
    public void setNickname(String nickname) {
        Nickname = nickname;
    }
    public void setEmail(String email) {
        Email = email;
    }
    public void setQuestion_password_recovery_question(String question_password_recovery_question) {
        Question_password_recovery_question = question_password_recovery_question;
    }

    public void setPassword_recovery_question(String password_recovery_question) {
        Password_recovery_question = password_recovery_question;
    }
    public void setLevel(int level) {
        Level = level;
    }
    public void setHP(int HP) {
        this.HP = HP;
    }

    public void setXP(int XP) {
        this.XP = XP;
    }

    public void setGold(int gold) {
        Gold = gold;
    }


}





