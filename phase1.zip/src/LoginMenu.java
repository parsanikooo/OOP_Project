import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.time.Duration;
import java.time.LocalTime;

public class LoginMenu {
    Controller controller;
    Scanner scanner;


    String LogedUsername ;
    public LoginMenu(Controller controller, Scanner scanner) {
        this.controller = controller;
        this.scanner = scanner;
    }

    public void run() {

        long n = 0 ;
        boolean loginfaild = false ;
        String input = "";
        String input_1 = "";
        Matcher matcher;
        LocalTime startTime = LocalTime.now();
        Duration duration ;
        System.out.println("you are in login menu");

        while (true){
            // if log in failed he must wait 5 * n seceond
            while (loginfaild){
                input_1 = scanner.nextLine();
                LocalTime endTime = LocalTime.now();
                duration = Duration.between(startTime, endTime);
                if ((n * 5) > duration.getSeconds()){
                    System.out.println("Try again in "+ (5*n - duration.getSeconds()) +" seconds");
                }
                else {
                    break;
                }
            }
            if (loginfaild){
                input = input_1 ;
            } else{
                input = scanner.nextLine();
            }
            if ((matcher = controller.getMatcher(input, "user login -u (?<username>.+) -p (?<password>.+)")) != null) {
                String username = matcher.group();
                String password = matcher.group();
                User user ;
                if ((user = User.getUserByUsername(username)) == null){
                    System.out.println("Username doesn’t exist!");
                    loginfaild = true ;
                    startTime =  LocalTime.now();
                    n++ ;
                    continue ;
                }
                else if (!Objects.equals(user.getPassword(), password)) {
                    System.out.println("Password and Username don’t match!");
                    loginfaild =true ;
                    startTime = LocalTime.now();
                    n++ ;
                    continue;
                }
                else {
                    System.out.println("user logged in successfully!");
                    LogedUsername = username ;
                    loginfaild = false ;
                }
            }
            else if ((matcher = controller.getMatcher(input, "Forgot my password -u (?<username>.+)")) != null) {
                User user ;
                String username = matcher.group("username");
                if ((user = User.getUserByUsername(username)) == null) {
                    System.out.println("Username doesn’t exist!");
                }
                else {
                    System.out.println(user.getQuestion_password_recovery_question());
                    String ans ;
                    boolean trueans = false ;
                    while (true){
                        ans = scanner.nextLine() ;
                        if (Objects.equals(user.getPassword_recovery_question(), ans)) {
                            trueans =true ;
                            break;
                        } else if (ans.equals("back")) {
                            break;
                        } else {
                            System.out.println("Your answer is wrong please try again!");
                        }
                    }
                    if (trueans) {
                        System.out.println("please enter your new password");
                        String ans_1 ;
                        while (true) {
                            ans_1 = scanner.nextLine();
                            if (ans_1.length() < 8) {
                                System.out.println("Password must have at least 8 characters");
                            } else if (!ans_1.matches("password")) {
                                System.out.println(" ");
                            } else {
                                break;
                            }
                        }
                        user.setPassword(ans_1);
                        System.out.println("your new password is " + ans_1);
                    }
                }
            }
        }
    }
}
