import java.awt.*;
import java.util.ArrayList;

public class Player {
    String username ;
    String Character ;
    ArrayList<Card> Cards = new ArrayList<Card>() ;
    int HP ;


}
