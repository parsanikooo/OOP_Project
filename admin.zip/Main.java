import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
public class Main {
    public static void main(String[] args) {
        File file = new File("Cards.text");
        Scanner scanner=new Scanner(System.in);
        ArrayList<Cards> cards = new ArrayList<>();
        Admin admin = new Admin();
        admin.run(cards,scanner);
    }
}