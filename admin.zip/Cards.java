public class Cards implements Cloneable {
    String name;
    int power, duration, playerdamage, upgradelevel, upgradecost, level;
    Chracter chracter;
    @Override
    protected Object clone() throws CloneNotSupportedException{
        Cards cards=(Cards)super.clone();
        return cards;

    }

    public Cards()
    {
        level=1;
    }

        public Cards(String name,int power,int duration,int playerdamage,int upgradecost,int upgradelevel)
    {
        this.name=name;
        this.upgradecost=upgradecost;
        this.playerdamage=playerdamage;
        this.power=power;
        this.duration=duration;
        this.upgradelevel=upgradelevel;
        level=1;
    }
    public int getUpgradecost()
    {
        return this.upgradecost;
    }
    public int getPower()
    {
        return this.power;
    }
    public int getDuration()
    {
        return this.duration;
    }
    public int getPlayerdamage()
    {
        return this.playerdamage;
    }
    public int  getUpgradelevel()
    {
        return this.upgradelevel;
    }
    public int getLevel()
    {
        return this.level;
    }
    public void setPower(int power)
    {
        this.power=power;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public void setLevel(int level)
    {
        this.level=level;
    }
    public void setDuration(int duration)
    {
        this.duration=duration;
    }
    public void setPlayerdamage(int playerdamage)
    {
        this.playerdamage=playerdamage;
    }
    public void setUpgradelevel(int upgradelevel)
    {
        this.upgradelevel=upgradelevel;
    }
    public void setUpgradecost(int upgradecost)
    {
        this.upgradecost=upgradecost;
    }

}
