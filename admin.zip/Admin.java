import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.ArrayList;
import java.util.Scanner;
public class Admin {
    String password = "password";

public String getPassword()
{
    return this.password;
}
public void setPassword(String password1){
    this.password=password1;
}
    private void SetthePower(Cards cards,Scanner scanner) {
        boolean exit = true;
        while (exit) {
            System.out.println("please enter the Card Power!");
            int power = scanner.nextInt();

            if (power < 10 || power > 100) {
                System.out.println("Invalid power!");
            } else {
                cards.power = power;
                System.out.println("Card Power added successfully!");
                exit = false;
            }
        }
    }

    private void SetthePowereditform(Cards cards,Scanner scanner) {
        boolean exit = true;
        while (exit) {
            System.out.println("please enter the new Card Power!");
            int power = scanner.nextInt();

            if (power < 10 || power > 100) {
                System.out.println("Invalid power!");
            } else {
                cards.power = power;
                System.out.println("Card Power edited successfully!");
                exit = false;
            }
        }
    }

    private void Settheduration(Cards cards,Scanner scanner) {
        boolean exit = true;
        while (exit) {
            System.out.println("please enter the card duration!");
            int duration = scanner.nextInt();

            if (duration < 1 || duration > 5) {
                System.out.println("Invalid duration!");
            } else {
                cards.duration = duration;
                System.out.println("Card duration added successfully!");
                exit = false;
            }
        }
    }

    private void Setthedurationeditform(Cards cards,Scanner scanner) {
        boolean exit = true;
        while (exit) {
            System.out.println("please enter the new card duration!");
            int duration = scanner.nextInt();

            if (duration < 1 || duration > 5) {
                System.out.println("Invalid duration!");
            } else {
                cards.duration = duration;
                System.out.println("Card duration edited successfully!");
                exit = false;
            }
        }
    }

    public void Settheplayerdamage(Cards cards,Scanner scanner) {
        boolean exit = true;
        while (exit) {
            System.out.println("please enter the card player damage!");
            int playerdamage = scanner.nextInt();

            if (playerdamage < 10 || playerdamage > 50) {
                System.out.println("Invalid player damage!");
            } else {
                cards.playerdamage = playerdamage;
                System.out.println("Card player damage added successfully!");
                exit = false;
            }
        }
    }

    private void Settheplayerdamageeditform(Cards cards,Scanner scanner) {
        boolean exit = true;
        while (exit) {
            System.out.println("please enter the new card player damage!");
            int playerdamage = scanner.nextInt();

            if (playerdamage < 10 || playerdamage > 50) {
                System.out.println("Invalid player damage!");
            } else {
                cards.playerdamage = playerdamage;
                System.out.println("Card player damage edited successfully!");
                exit = false;
            }
        }
    }

    private void editcard(Cards cards,Scanner scanner) {
        System.out.println("Which part do you want to edit?");
        System.out.println("1.Name:" + cards.name);
        System.out.println("2.Power:" + cards.power);
        System.out.println("3.Duration:" + cards.duration);
        System.out.println("4.Upgrade cost:" + cards.upgradecost);
        System.out.println("5.Upgrade level:" + cards.upgradelevel);
        System.out.println("6.Player damage:" + cards.playerdamage);
        System.out.println("7.Level:" + cards.level);

        int input = scanner.nextInt();
        if (input == 1) {
            System.out.println("Please enter new name!");
            String name = scanner.nextLine();
            cards.name = name;
            System.out.println("Card name edited successfully");
        }
        if (input == 2) {
            this.SetthePowereditform(cards,scanner);
        }
        if (input == 3) {
            this.Setthedurationeditform(cards,scanner);
        }
        if (input == 4) {
            System.out.println("Please enter new upgrade cost!");
            int upgradecost = scanner.nextInt();
            cards.upgradecost = upgradecost;
            System.out.println("Card name upgrade cost successfully");
        }
        if (input == 5) {
            System.out.println("Please enter new upgrade level!");
            int upgradelevel = scanner.nextInt();
            cards.upgradelevel = upgradelevel;
            System.out.println("Card upgrade level edited successfully");
        }
        if (input == 6) {
            this.Settheplayerdamageeditform(cards,scanner);
        }

    }
    private void addcard(Cards cards,Scanner scanner)
    {
        System.out.println("please enter the Card Name!");
        String name = new String(scanner.nextLine());
        System.out.println("Card name accepted");

        System.out.println("please enter the Card Upgrade cost!");
        int upgradecost = scanner.nextInt();
        System.out.println("Card upgrade cost added successfully");

        System.out.println("please enter the Upgrade level!");
        int upgradelevel = scanner.nextInt();
        System.out.println("Card upgrade level added successfully");

        cards.name=name;
        cards.upgradecost=upgradecost;
        cards.upgradelevel=upgradelevel;
        this.Settheduration(cards,scanner);
        this.SetthePower(cards,scanner);
        this.Settheplayerdamage(cards,scanner);
        cards.level=1;
    }
    public void run(ArrayList<Cards> cards,Scanner scanner){

        Pattern patternloginadmin = Pattern.compile("\\s*-\\s*login\\s+admin\\s+(.+)\\s*");
        Pattern patternaddcard = Pattern.compile("\\s*-\\s*add\\s+card\\s*");
        Pattern patterneditcard = Pattern.compile("\\s*-\\s*edit\\s+card\\s*");
        Pattern patternExit = Pattern.compile("\\s*-\\s*exit\\s*");

        String Invalidcomendaddcard;

        boolean exit = true;
        boolean exitaddcard=true;
        boolean InvaldIinput = true;


        String input=new String();

        input = scanner.nextLine();

        Matcher matcherloginadmin = patternloginadmin.matcher(input);

        if (matcherloginadmin.find()) {

            if (matcherloginadmin.group(1).equals(this.password)) {

                System.out.println("Admin loged in successfuly!");
                while (exit) {

                    System.out.println("Please enter menu!");

                    input = scanner.nextLine();
                    while (input.trim().isEmpty())
                        input = scanner.nextLine();
                    Matcher matcherexit = patternExit.matcher(input);
                    if (matcherexit.find()) {
                        exit = false;
                        InvaldIinput = false;
                    } else {
                        Matcher matcheraddcard = patternaddcard.matcher(input);
                        Matcher matchereditcard = patterneditcard.matcher(input);
                        if (matcheraddcard.find()) {
                            Cards cards1=new Cards();
                            this.addcard(cards1,scanner);
                            cards.add(cards1);
                            InvaldIinput = false;

                            System.out.println("Card added successfully!");

                            System.out.println("Returned to login menu!");


                        }
                        else
                        if (matchereditcard.find())
                        {
                            for (int i=0;i<cards.size();i++)
                            {
                                System.out.println((i+1)+" "+cards.get(i).name);
                            }
                            int index=scanner.nextInt();

                            index--;

                            this.editcard(cards.get(index),scanner);

                            System.out.println("Returned to login menu!");

                        }
                    }
                }
            }
            else {
                System.out.println("Invalid Password for Admin");
            }
        }

        else
        if (InvaldIinput == true)
            if (input!="")
                System.out.println("Invalid commend");
    }
}

