public enum Chracter {
    loghman,
    hitler,
    mokhtar,
    vahdat

}
