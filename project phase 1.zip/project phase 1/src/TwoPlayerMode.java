import com.sun.source.tree.IfTree;

import java.time.Duration;
import java.time.LocalTime;
import java.util.*;
import java.util.regex.Matcher;

public class TwoPlayerMode {
    Controller controller ;
    Scanner scanner ;
    User user_1 ;
    User user_2 ;
    Player Player_1 ;
    Player Player_2 ;
    String Character_1 ;
    String Character_2 ;
    boolean logedin = false ;



    public TwoPlayerMode(Controller controller, Scanner scanner) {
        this.controller = controller ;
        this.scanner = scanner ;
    }


    public void run(){
        user_1 = User.getUserByUsername(controller.loginMenu.LogedUsername) ;
        LoginPlayer2();
        if (logedin){
            Player_1 = new Player(user_1) ;
            Player_2 = new Player(user_2) ;
            SelectCharacter() ;
            int who = ChosePlayer() ;
            StartGame() ;
            MainGame(who) ;




        }


    }

    private void MainGame(int who) {
        Matcher matcher ;
        ShowGame() ;
        while (true){
            if (Player_1.getTurns() == 0 && Player_2.getTurns() == 0) {

            }
            else if (who == 1 && Player_1.getTurns() > 0){
                System.out.println("Player 1 turn");
                String input = scanner.nextLine() ;
                if ((matcher = controller.getMatcher(input,"-Select card number (?<n>.+) player (?<x>.+)") ) != null){
                    int n =  Integer.parseInt(matcher.group("n")) ;
                    int x =  Integer.parseInt(matcher.group("x")) ;
                    if (x != 1){
                        System.out.println("Player 1 turn !!");
                    }
                    else {

                    }
                }

            }
            else if (who == 2 && Player_2.getTurns() > 0) {
                System.out.println("Player 2 turn");
                String input = scanner.nextLine() ;

            }
        }

    }


    private void ShowGame() {
        System.out.println("--------------------------------------------------------");
        System.out.println("Player 1 Character : " + Player_1.getCharacter());
        System.out.println("Player 1 HP : "+ Player_1.getHP());
        System.out.println("Player 1 round left : " + Player_1.getTurns());
        int total = 0 ;
        for (int i = 0; i < 21; i++) {
            if (Objects.equals(Player_1.getMap()[i].getType(), "damage/healing")){
                total += Player_1.getMap()[i].showdamage() ;
            }
        }
        System.out.println("Player 1 damage : " + total);
        System.out.println("Player 1 Hand Card : ");
        for (int i = 0; i < 4 ; i++) {
            for (int j = 0; j < Player_1.getHand().size(); j++) {
                if (i == 0){
                    System.out.print("| ");
                    System.out.print(Player_1.getHand().get(j).getType());
                    System.out.print(" |");
                }
                else if (i == 1) {
                    System.out.print("| ");
                    System.out.print(Player_1.getHand().get(j).getPower());
                    System.out.print(" |");
                }
                else if (i == 2) {
                    System.out.print("| ");
                    System.out.print(Player_1.getHand().get(j).getPlayerdamage());
                    System.out.print(" |");
                }
                else if (i == 3) {
                    System.out.print("| ");
                    System.out.print(Player_1.getHand().get(j).getDuration());
                    System.out.print("  |");
                }

            }
            System.out.println();
        }
        System.out.println("--------------------------MAP---------------------------");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 21; j++) {
                if (i == 0){
                    System.out.print("| ");
                    System.out.print(Player_1.getMap()[j].getPower());
                    System.out.print(" |");
                }
                else if (i == 1) {
                    System.out.print("| ");
                    System.out.print(Player_1.getMap()[j].showdamage());
                    System.out.print("  |");
                }
            }
            System.out.println();
        }
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 21; j++) {
                if (i == 0){
                    System.out.print("| ");
                    System.out.print(Player_2.getMap()[j].getPower());
                    System.out.print(" |");
                }
                else if (i == 1) {
                    System.out.print("| ");
                    System.out.print(Player_2.getMap()[j].showdamage());
                    System.out.print("  |");
                }
            }
            System.out.println();
        }
        System.out.println("--------------------------MAP---------------------------");
        System.out.println("Player 2 Character : " + Player_2.getCharacter());
        System.out.println("Player 2 HP : "+ Player_2.getHP());
        System.out.println("Player 2 round left : " + Player_2.getTurns());
        total = 0 ;
        for (int i = 0; i < 21; i++) {
            if (Objects.equals(Player_2.getMap()[i].getType(), "damage/healing")){
                total += Player_2.getMap()[i].showdamage() ;
            }
        }
        System.out.println("Player 2 damage : " + total);
        System.out.println("Player 2 Hand Card : ");
        for (int i = 0; i < 4 ; i++) {
            for (int j = 0; j < Player_2.getHand().size(); j++) {
                if (i == 0){
                    System.out.print("| ");
                    System.out.print(Player_2.getHand().get(j).getType());
                    System.out.print(" |");
                }
                else if (i == 1) {
                    System.out.print("| ");
                    System.out.print(Player_2.getHand().get(j).getPower());
                    System.out.print(" |");
                }
                else if (i == 2) {
                    System.out.print("| ");
                    System.out.print(Player_2.getHand().get(j).getPlayerdamage());
                    System.out.print(" |");
                }
                else if (i == 3) {
                    System.out.print("| ");
                    System.out.print(Player_2.getHand().get(j).getDuration());
                    System.out.print("  |");
                }

            }
            System.out.println();
        }
        System.out.println("--------------------------------------------------------");




    }


    private void StartGame() {
        Player_1.RandomCard() ;
        Player_2.RandomCard() ;
        Player_1.CreateeMap() ;
        Player_2.CreateeMap() ;
    }

    private int ChosePlayer() {
        Random rand = new Random();
        int flag = rand.nextInt(10) ;
        if (flag <6){
            System.out.println("Player 1 will start");
            return 1 ;
        }else{
            System.out.println("Player 2 will start");
            return 2 ;
        }
    }

    private void SelectCharacter() {
        System.out.println("Player 1 please selevt your character");
        System.out.println("1-Hitler");
        System.out.println("2-Mokhtar");
        System.out.println("3-Loghman");
        System.out.println("4-Vahdat");
        while (true){
            String input = scanner.nextLine() ;
            if (Objects.equals(input, "1")){
                Character_2 = "Hitler" ;
                break;
            }
            else if (Objects.equals(input, "2")) {
                Character_2 = "Mokhtar" ;
                break;
            }
            else if (Objects.equals(input, "3")) {
                Character_2 = "Loghman" ;
                break;
            }
            else if (Objects.equals(input, "4")) {
                Character_2 = "Vahdat" ;
                break;
            }else{
                System.out.println("invalid command!");
            }
        }
        System.out.println("Player 2 please selevt your character");
        System.out.println("1-Hitler");
        System.out.println("2-Mokhtar");
        System.out.println("3-LoghmaN");
        System.out.println("4-Vahdat");
        while (true){
            String input = scanner.nextLine() ;
            if (Objects.equals(input, "1")){
                Character_2 = "Hitler" ;
                break;
            }
            else if (Objects.equals(input, "2")) {
                Character_2 = "Mokhtar" ;
                break;
            }
            else if (Objects.equals(input, "3")) {
                Character_2 = "Loghman" ;
                break;
            }
            else if (Objects.equals(input, "4")) {
                Character_2 = "Vahdat" ;
                break;
            }else{
                System.out.println("invalid command!");
            }
        }
        Player_1.setCharacter(Character_1);
        Player_2.setCharacter(Character_2);
        System.out.println("Player 1 character is "+Character_1);
        System.out.println("Player 2 character is "+Character_2);
    }

    private void LoginPlayer2(){

        long n = 0 ;
        boolean loginfaild = false ;
        String input = "";
        String input_1 = "";
        Matcher matcher;
        LocalTime startTime = LocalTime.now();
        Duration duration ;
        System.out.println("Please log in Player 2");

        while (true) {
            // if log in failed he must wait 5 * n second
            while (loginfaild) {
                input_1 = scanner.nextLine();
                LocalTime endTime = LocalTime.now();
                duration = Duration.between(startTime, endTime);
                if ((n * 5) > duration.getSeconds()) {
                    System.out.println("Try again in " + (5 * n - duration.getSeconds()) + " seconds");
                } else {
                    break;
                }
            }
            if (loginfaild) {
                input = input_1;
            } else {
                input = scanner.nextLine();
            }
            if ((matcher = controller.getMatcher(input, "user login -u (?<username>.+) -p (?<password>.+)")) != null) {
                String username = matcher.group();
                String password = matcher.group();
                User user;
                if ((user = User.getUserByUsername(username)) == null) {
                    System.out.println("Username doesn’t exist!");
                    loginfaild = true;
                    startTime = LocalTime.now();
                    n++;
                    continue;
                } else if (!Objects.equals(user.getPassword(), password)) {
                    System.out.println("Password and Username don’t match!");
                    loginfaild = true;
                    startTime = LocalTime.now();
                    n++;
                    continue;
                } else {
                    System.out.println("user logged in successfully!");
                    user_2 = User.getUserByUsername(username) ;
                    logedin = true ;
                    loginfaild = false;
                    break;
                }
            }
            else {
                    System.out.println("invalid command !");
            }
        }
    }



}
