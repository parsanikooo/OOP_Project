
import java.util.regex.*;



public class Card implements Cloneable {


    String name;
    int power, duration, playerdamage, upgradelevel, upgradecost, level;
    String Chracter;

    public Card(String name, int power, int duration, int playerdamage,  int upgradelevel , int upgradecost)
    {
        this.name=name;
        this.upgradecost=upgradecost;
        this.playerdamage=playerdamage;
        this.power=power;
        this.duration=duration;
        this.upgradelevel=upgradelevel;
        level=1;
    }


    public Card()
    {
        level=1;
    }

    public int getUpgradecost()
    {
        return this.upgradecost;
    }
    public int getPower()
    {
        return this.power;
    }
    public int getDuration()
    {
        return this.duration;
    }
    public int getPlayerdamage()
    {
        return this.playerdamage;
    }
    public int  getUpgradelevel()
    {
        return this.upgradelevel;
    }
    public int getLevel()
    {
        return this.level;
    }
    public void setPower(int power)
    {
        this.power=power;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public void setLevel(int level)
    {
        this.level=level;
    }
    public void setDuration(int duration)
    {
        this.duration=duration;
    }
    public void setPlayerdamage(int playerdamage)
    {
        this.playerdamage=playerdamage;
    }
    public void setUpgradelevel(int upgradelevel)
    {
        this.upgradelevel=upgradelevel;
    }
    public void setUpgradecost(int upgradecost)
    {
        this.upgradecost=upgradecost;
    }

    public int showdamage(){
        return this.playerdamage / this.duration ;
    }
    public void increasedamage(){
        this.playerdamage += this.duration * 3 ;
    }

    public String getType(){
        Pattern pattern = Pattern.compile("\\s*Card\\s*(.*)\\s*");
        Matcher matcher=pattern.matcher(this.name);
        if (matcher.find())
        {
            return "damage/healing" ;
        }
        return  this.name ;

    }

    @Override
    public Object clone() {
        try{
            Card card=(Card) super.clone();
            return card;
        }
        catch (CloneNotSupportedException e){
            throw new AssertionError() ;
        }

    }

}
