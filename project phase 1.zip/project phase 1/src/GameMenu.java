import java.util.Objects;
import java.util.Scanner;

public class GameMenu {

    Controller controller;
    Scanner scanner;


    public GameMenu(Controller controller, Scanner scanner) {
        this.controller = controller ;
        this.scanner = scanner ;
    }


    public void run(){
        System.out.println("Please select mode");
        while (true){
            String input = scanner.nextLine() ;
            if (Objects.equals(input, "mode 1")){
                controller.twoPlayerMode.run();
            }
            else if (Objects.equals(input, "mode 2")) {

            }
            else if (Objects.equals(input, "back")){

            }
            else {
                System.out.println("invalid input !");
            }
        }
    }
}
