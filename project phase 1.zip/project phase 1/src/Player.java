import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.Random;

public class Player {
    private String username ;
    private String Character ;
    private ArrayList<Card> Cards ;
    private int HP ;
    private int turns;
    private ArrayList<Card> Hand  ;
    private Card[] Map ;



    public Player(User user) {
        this.username = user.getUsername() ;
        this.Cards = new ArrayList<Card>() ;
        this.HP = user.getHP() ;
        turns = 4 ;
        this.Hand  = new ArrayList<Card>() ;
        this.Map = new Card[21] ;
        for (int i = 0; i < user.getCards().size(); i++) {
            this.Cards.add((Card) user.getCards().get(i).clone()) ;
        }
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCharacter() {
        return Character;
    }

    public void setCharacter(String character) {
        Character = character;
    }

    public ArrayList<Card> getCards() {
        return Cards;
    }

    public void setCards(ArrayList<Card> cards) {
        Cards = cards;
    }

    public int getHP() {
        return HP;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }

    public  ArrayList<Card> getHand() {
        return this.Hand;
    }

    public void setHand(ArrayList<Card> hand) {
        this.Hand = hand;
    }

    public Card[] getMap() {
        return Map;
    }

    public void setMap(Card[] map) {
        Map = map;
    }

    public int getTurns() {
        return turns;
    }

    public void setTurns(int turns) {
        this.turns = turns;
    }



    public void RandomCard() {
        int index = this.Cards.size() ;
        Random rand = new Random() ;
        for (int i = 0; i < 5; i++) {
            this.Hand.add((Card) this.Cards.get(rand.nextInt(index)).clone()) ;
        }
    }

    public void CreateeMap() {
        Random rand = new Random() ;
        int index = rand.nextInt(21);
        for (int i = 0; i < 21; i++) {
            if (i == index ){
                Card card = new Card("Whole" , 0 , 1 , 0 , 1 ,0 ) ;
                this.Map[i] = (Card) card.clone();
            }else{
                Card card = new Card("Block" , 0 , 1 , 0 , 1 ,0 ) ;
                this.Map[i] = (Card) card.clone();
            }
        }
    }
}
