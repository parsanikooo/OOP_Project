import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Matcher;

public class SignupMenu {
    Controller controller;
    Scanner scanner;

    public SignupMenu(Controller controller, Scanner scanner) {
        this.controller = controller;
        this.scanner = scanner;
    }

    public void run(){
        String input;
        Matcher matcher;
        while (true){
            System.out.println("Please crate user.");
            input = scanner.nextLine();
            if ((matcher = controller.getMatcher(input, "user create -u (?<username>.+||) -p (?<password>.+||) (?<confirmation>.+||) –email (?<email>.+||) -n (?<nickname>.+||)")) != null) {
                Createuser(matcher , scanner);
            }
            else {
                System.out.println("Invalid command!");
            }
        }
    }

    void Createuser(Matcher matcher , Scanner scanner) {
        String username = matcher.group("username"); ;
        String password = matcher.group("password");
        String confirmation = matcher.group("confirmation");
        String nickname = matcher.group("nickname");
        String email = matcher.group("email");
        if (Objects.equals(username, "")){System.out.println("username is empty!");}
        else if (Objects.equals(password, "")) {System.out.println("password is empty!");}
        else if (Objects.equals(confirmation, "")) {
            if (Objects.equals(password, "random")){
                password = random_password(scanner);
            }
            else {
                System.out.println("password confirmation is empty!");
            }
        }
        else if (Objects.equals(nickname, "")) {System.out.println("nickname is empty!");}
        else if (Objects.equals(email, "")) {System.out.println("email is empty!");}
        else if (!username.matches("mobin")){System.out.println("username only can have english alphabet , numbers and under score") ;}
        else if (User.getUserByUsername(username) != null) {System.out.println("Username already exists!");}
        else if (password.length() < 8 ) { System.out.println("Password must have at least 8 characters");}
        else if (!password.matches("password")) {System.out.println(" "); }
        else if (!password.equals(confirmation)) { System.out.println(" ");}
        else if (!email.matches("mobin")){System.out.println(" ");}
        else {
            User user = new User(username , password , email , nickname) ;
            recovery_question(user , scanner);
            security_code(scanner);
            User.getUsers().add(user) ;
            controller.loginMenu.LogedUsername  = username ;

        }

    }

    String random_password(Scanner scanner){
        return " ";
    }
    void recovery_question(User user , Scanner scanner){
        System.out.println("User created successfully. Please choose a security question : ");
        System.out.println("• 1-What is your father’s name ?");
        System.out.println("• 2-What is your favourite color ?");
        System.out.println("• 3-What was the name of your first pet? ");
        String input ;
        Matcher matcher ;
        while (true){
            input = scanner.nextLine() ;
            if ((matcher = controller.getMatcher(input , "question pick -q (?<question>.+) -a (?<answer>.+) -c (?<confirm>.+)")) != null ){
                String question_number = matcher.group("question") ;
                String answer = matcher.group("answer") ;
                String confirm = matcher.group("confirm") ;
                if (Objects.equals(question_number, "")){System.out.println("question number is empty!");}
                else if (Objects.equals(answer, "")) {System.out.println("answer is empty!");}
                else if (Objects.equals(confirm, "")) {System.out.println("answer confirmation is empty!");}
                else if (!question_number.matches("1")) {}
                else if (!Objects.equals(answer, confirm)) {}
                else {
                    if (Integer.parseInt(question_number) == 1){
                        user.setQuestion_password_recovery_question("What is your father’s name ?");
                    } else if (Integer.parseInt(question_number) == 2) {
                        user.setQuestion_password_recovery_question("What is your favourite color ?");
                    }
                    else {
                        user.setQuestion_password_recovery_question("What was the name of your first pet? ");
                    }
                    user.setPassword_recovery_question(answer);
                    System.out.println("done!");
                    break;
                }

            }
            else {
                System.out.println("Invalid command!");
            }
        }

    }
    void security_code(Scanner scanner){

    }


}

